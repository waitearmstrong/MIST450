﻿namespace FirstMVCAppArmstrong.Models
{
    public class Major
    {
        public Major()
        {
        }
    }
}